"""Tests for docstring parser."""
